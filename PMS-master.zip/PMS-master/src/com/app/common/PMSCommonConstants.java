package com.app.common;

public class PMSCommonConstants {

	
	public static final  String ADMIN="ADMIN";
	public static final  String MANAGER="MANAGER";
	public static final  String MEMBER="MEMBER";
	public static final  String TODO="TODO";
	public static final  String UNASSIGNED="UNASSIGNED";
	public static final  String ASSIGNED="ASSIGNED";
	public static final  String INPROGRESS="INPROGRESS";
	public static final  String COMPLETED="COMPLETED";
	public static final  String DEFAULT_PASSWORD="Project@123";
	public static final  String CLIENT="CLIENT";
	
	
}
